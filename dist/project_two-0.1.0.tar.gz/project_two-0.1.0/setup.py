# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['project_two']

package_data = \
{'': ['*']}

install_requires = \
['simple-chalk>=0.1.0,<0.2.0']

entry_points = \
{'console_scripts': ['start = project_two.main:game_loop']}

setup_kwargs = {
    'name': 'project-two',
    'version': '0.1.0',
    'description': 'A text-based RPG game',
    'long_description': "# Welcome to TextDungeon\n\nTo run this game, you need to have the following:\n- Python >3.6, <=3.10\n- Poetry (optional for coloured output)\n\n## Install Poetry\n### Windows\n```commandline\n    (Invoke-WebRequest -Uri https://install.python-poetry.org -UseBasicParsing).Content | python -\n```\n\n### *nix based systems\n```commandline\n    curl -sSL https://install.python-poetry.org | python3 -\n```\n\n## Build game\n```\n    cd textdungeon\n    poetry install && poetry lock\n```\n\nThen run the game with `poetry run start`\n\nIf you don't have poetry installed, or don't want to have poetry installed:\n```commandline\n    cp dungeon_map.json ./project_two\n    cd project_two\n    python main.py\n```\n\nIf you want to have colors enabled for prompt, without poetry:\n```commandline\n    pip install simple_chalk\n    cp dungeon_map.json ./project_two\n    python main.py\n```",
    'author': 'Brett Plemons',
    'author_email': 'Brett.Plemons@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
